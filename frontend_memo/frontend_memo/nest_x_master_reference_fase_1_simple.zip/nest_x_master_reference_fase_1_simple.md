# NestX — Master Reference Fase 1 (Simple)

> Documento di riferimento unico per la Fase 1 di NestX.
> Questo file raccoglie **decisioni definitive** e **concetti base** condivisi.
> Tutto ciò che non è qui dentro è da considerarsi **non attivo** o **rimandato a fasi successive**.

---

## 1️⃣ Scope della Fase 1

La Fase 1 di NestX ha come obiettivo:
- validare il **social**
- validare l’**esperienza utente**
- costruire **base utenti reali**
- preparare l’infrastruttura per fasi successive

**NON** ha come obiettivo:
- monetizzazione reale
- conversione token → denaro
- payout verso utenti

---

## 2️⃣ Token System — Stato Fase 1

### Stato generale
- Il **token system esiste come struttura concettuale e tecnica**
- Il ledger interno può essere presente (per tracciabilità)
- **NON è attiva alcuna forma di monetizzazione**
- **NON è attiva la ricarica token da parte degli utenti**
- **NON è attivo alcun payout**

I token **non rappresentano valore economico convertibile** in questa fase.

---

### Token promozionali (Promo Token)

Eventuali token distribuiti in Fase 1:
- sono **token promozionali**
- sono **a carico della piattaforma**
- hanno scopo di **incentivo e test dell’interazione**

I promo token:
- possono circolare internamente
- possono essere usati per interazioni
- **NON generano automaticamente diritti di riscossione**
- **NON implicano debito monetario verso i creator**

> ⚠️ La trasformazione dei token promozionali in valore monetizzabile **NON fa parte della Fase 1**.
>
> Qualsiasi decisione su:
> - monetizzazione dei promo token
> - payout verso creator
> - trattamento fiscale
>
> verrà definita **solo dopo consulenza fiscale dedicata**.

---

## 3️⃣ Ruoli Utente — Panoramica

### Utente Base
- Account standard alla registrazione
- Nessuna monetizzazione
- Nessun payout
- Accesso completo alle funzioni social di base

---

### Utente VIP

Il VIP è un **utente avanzato**, NON un creator.

Il VIP:
- **NON monetizza**
- **NON fa ADV**
- **NON riceve payout**

Il VIP migliora **esperienza, visibilità e strumenti**, non il guadagno.

---

## 4️⃣ Benefici VIP — Fase 1

### Chat & Messaggi
- Può **cancellare i propri messaggi**
- Può scrivere nelle **chat delle live senza token**
- Limite messaggi giornalieri:
  - Base: **10**
  - VIP: **100**

---

### Feed & Visibilità
- Feed **personalizzato prioritario**
- Contenuti meno penalizzati dall’algoritmo

---

### Vetrina VIP
- Accesso alla **Vetrina**
- **2 item gratuiti a settimana**
- Oltre i limiti → pagamento singolo (fase successiva)
- La Vetrina **non è un marketplace**

---

### Donazioni
- **Solo account VIP possono ricevere donazioni**
- Ricezione ≠ monetizzazione
- Nessun payout in Fase 1

---

### Contenuti Multimediali
- Video nei post:
  - Base: **max 1 minuto**
  - VIP: **max 3 minuti**

---

### Sondaggi
- **Solo VIP può creare sondaggi**
- **Solo VIP può modificare il proprio voto**

---

## 5️⃣ Creator — Fase 1

### Requisiti e processo di approvazione (definitivo)

Lo status Creator viene assegnato **solo** quando:
1) la verifica esterna (es. Stripe) risulta completata e l’utente è tecnicamente idoneo **e**
2) l’admin concede l’approvazione finale.

La piattaforma può rifiutare o revocare lo status Creator se l’account presenta:
- restrizioni attive
- segnalazioni gravi o ripetute
- blocchi/ban recenti
- violazioni delle regole o verifiche pendenti

Il **badge Creator** deve comparire **solo dopo** l’approvazione finale (verifica esterna + admin).

### Stato Creator
- Account verificato
- Può creare contenuti avanzati
- **NON monetizza in Fase 1**
- Nessun payout

> Nota di coerenza (da verificare): il badge Creator deve risultare visibile **solo** dopo l’approvazione finale (verifica esterna + admin). Verificare che backend/frontend siano coerenti con questa regola.

---

### ADV Creator
- Ogni creator ha **1 slot ADV gratuito al giorno**
- ADV aggiuntivi → pagamento singolo (fase successiva)
- Possibili pacchetti → da valutare

Gli ADV sono:
- **esclusivamente per i creator**
- **NON disponibili per i VIP**

---

## 6️⃣ Cose Escluse dalla Fase 1

In Fase 1 NON sono attivi:
- Monetizzazione reale
- Conversione token → denaro
- Payout
- Token acquistabili
- Token riscattabili
- Premium tiers aggiuntivi

---

## 7️⃣ Nota di Metodo (Importante)

Questo documento è la **base ufficiale** della Fase 1.

- Le decisioni qui scritte sono da considerarsi **stabili**
- Eventuali aggiunte future verranno fatte **una sola volta**, in modo esplicito
- Nulla va interpretato implicitamente

---

> Ultimo aggiornamento: consolidamento Token + VIP

