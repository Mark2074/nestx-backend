C:\Users\laure\NestX\bibbia di nestx
C:\Users\laure\NestX\bibbia di nestx\da fare appena online.md
C:\Users\laure\NestX\bibbia di nestx\elenco file.md
C:\Users\laure\NestX\bibbia di nestx\nest_x_master_reference_fase_1_simple.md
C:\Users\laure\NestX\bibbia di nestx\NESTX_MASTER_REFERENCE_PHASE1_SINGLE.md
C:\Users\laure\NestX\bibbia di nestx\NESTX_MASTER_REFERENCE_v1.md

C:\Users\laure\NestX\logo
C:\Users\laure\NestX\logo\2352301463.jpg
C:\Users\laure\NestX\logo\ChatGPT Image 21 gen 2026, 09_58_05.png
C:\Users\laure\NestX\logo\nestx-horizontal-dark_1.png
C:\Users\laure\NestX\logo\nestx-horizontal-dark.png
C:\Users\laure\NestX\logo\nestx-symbol-dark.png
C:\Users\laure\NestX\logo\nestx-vertical-dark.png

C:\Users\laure\NestX\nestx-backend
C:\Users\laure\NestX\nestx-backend\front-end
C:\Users\laure\NestX\nestx-backend\front-end\concept NestX sezione centrale
C:\Users\laure\NestX\nestx-backend\frontend_memo

C:\Users\laure\NestX\nestx-backend\middleware
C:\Users\laure\NestX\nestx-backend\middleware\adminGuard.js
C:\Users\laure\NestX\nestx-backend\middleware\authMiddleware.js
C:\Users\laure\NestX\nestx-backend\middleware\featureGuard.js
C:\Users\laure\NestX\nestx-backend\middleware\internalServiceGuard.js

C:\Users\laure\NestX\nestx-backend\models
C:\Users\laure\NestX\nestx-backend\models\AccountTrustRecord.js
C:\Users\laure\NestX\nestx-backend\models\ActionAuditLog.js
C:\Users\laure\NestX\nestx-backend\models\AdminAuditLog.js
C:\Users\laure\NestX\nestx-backend\models\adv.js
C:\Users\laure\NestX\nestx-backend\models\ageGateLog.js
C:\Users\laure\NestX\nestx-backend\models\block.js
C:\Users\laure\NestX\nestx-backend\models\Comment.js
C:\Users\laure\NestX\nestx-backend\models\dailyQuota.js
C:\Users\laure\NestX\nestx-backend\models\event.js
C:\Users\laure\NestX\nestx-backend\models\Follow.js
C:\Users\laure\NestX\nestx-backend\models\LivePresence.js
C:\Users\laure\NestX\nestx-backend\models\LiveRoom.js
C:\Users\laure\NestX\nestx-backend\models\message.js
C:\Users\laure\NestX\nestx-backend\models\MessageDailyCounter.js
C:\Users\laure\NestX\nestx-backend\models\MutedUser.js
C:\Users\laure\NestX\nestx-backend\models\notification.js
C:\Users\laure\NestX\nestx-backend\models\payoutRequest.js
C:\Users\laure\NestX\nestx-backend\models\PollVote.js
C:\Users\laure\NestX\nestx-backend\models\Post.js
C:\Users\laure\NestX\nestx-backend\models\PostLike.js
C:\Users\laure\NestX\nestx-backend\models\ProhibitedSearchLog.js
C:\Users\laure\NestX\nestx-backend\models\Report.js
C:\Users\laure\NestX\nestx-backend\models\SensitiveDictionaryEntry.js
C:\Users\laure\NestX\nestx-backend\models\showcaseItem.js
C:\Users\laure\NestX\nestx-backend\models\ticket.js
C:\Users\laure\NestX\nestx-backend\models\TokenAuditLog.js
C:\Users\laure\NestX\nestx-backend\models\tokenTransaction.js
C:\Users\laure\NestX\nestx-backend\models\user.js
C:\Users\laure\NestX\nestx-backend\node_modules

C:\Users\laure\NestX\nestx-backend\routes
C:\Users\laure\NestX\nestx-backend\routes\adminAdvRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminContentRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminDictionaryRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminNotifications.routes.js
C:\Users\laure\NestX\nestx-backend\routes\adminPayoutRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminQueueRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminRefundRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminReportsRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminSearchLogsRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminTrustRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminUsersRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\adminVerifications.routes.js
C:\Users\laure\NestX\nestx-backend\routes\advRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\aiModerationRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\appSettingsRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\auth.routes.js
C:\Users\laure\NestX\nestx-backend\routes\blockRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\eventPromoRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\eventRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\followRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\liveRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\liveSearchRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\mediaRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\messageRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\muteRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\notifications.js
C:\Users\laure\NestX\nestx-backend\routes\oldLiveRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\payoutRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\posts.js
C:\Users\laure\NestX\nestx-backend\routes\profile.routes.js
C:\Users\laure\NestX\nestx-backend\routes\profileEventBannerRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\reportRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\searchRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\showcaseRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\stripeConnectRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\stripeWebhookRoutes.js
C:\Users\laure\NestX\nestx-backend\routes\tokens.js
C:\Users\laure\NestX\nestx-backend\routes\verificationRoutes.js

C:\Users\laure\NestX\nestx-backend\scripts
C:\Users\laure\NestX\nestx-backend\scripts\checkMongoVersion.js
C:\Users\laure\NestX\nestx-backend\scripts\migrate_posts_media.js
C:\Users\laure\NestX\nestx-backend\scripts\migrate-follow-status.js
C:\Users\laure\NestX\nestx-backend\scripts\where_am_i.js

C:\Users\laure\NestX\nestx-backend\services
C:\Users\laure\NestX\nestx-backend\services\economyService.js

C:\Users\laure\NestX\nestx-backend\strutture e decisioni NestX
C:\Users\laure\NestX\nestx-backend\uploads

C:\Users\laure\NestX\nestx-backend\utils
C:\Users\laure\NestX\nestx-backend\utils\blockUtils.js
C:\Users\laure\NestX\nestx-backend\utils\getMutedUserIds.js

C:\Users\laure\NestX\nestx-backend\vecchi file
C:\Users\laure\NestX\nestx-backend\vecchi file\auth.js
C:\Users\laure\NestX\nestx-backend\vecchi file\profileOldLiveRoutes.js
C:\Users\laure\NestX\nestx-backend\vecchi file\usersSocial.js

C:\Users\laure\NestX\nestx-backend\.env
C:\Users\laure\NestX\nestx-backend\package-lock.json
C:\Users\laure\NestX\nestx-backend\package.json
C:\Users\laure\NestX\nestx-backend\server.js
C:\Users\laure\NestX\nestx-backend\stripe.exe

C:\Users\laure\NestX\nestx-frontend
C:\Users\laure\NestX\nestx-frontend\file superati
C:\Users\laure\NestX\nestx-frontend\memo
C:\Users\laure\NestX\nestx-frontend\node_modules
C:\Users\laure\NestX\nestx-frontend\public
C:\Users\laure\NestX\nestx-frontend\public\legal
C:\Users\laure\NestX\nestx-frontend\public\vite.svg
C:\Users\laure\NestX\nestx-frontend\src

C:\Users\laure\NestX\nestx-frontend\src\api
C:\Users\laure\NestX\nestx-frontend\src\api\nestxApi.ts

C:\Users\laure\NestX\nestx-frontend\src\assets
C:\Users\laure\NestX\nestx-frontend\src\assets\react.svg

C:\Users\laure\NestX\nestx-frontend\src\components
C:\Users\laure\NestX\nestx-frontend\src\components\feed
C:\Users\laure\NestX\nestx-frontend\src\components\feed\EventCard.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\feed\PostCard.tsx

C:\Users\laure\NestX\nestx-frontend\src\components\profile
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileComposer.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileEditorCard.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileEventBannerCard.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileHeaderMy.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfilePayoutCard.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileTabsMy.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\profile\ProfileVerificationCard.tsx

C:\Users\laure\NestX\nestx-frontend\src\components\search
C:\Users\laure\NestX\nestx-frontend\src\components\search\SearchFilters.tsx
C:\Users\laure\NestX\nestx-frontend\src\components\EmailVerifyBanner.tsx

C:\Users\laure\NestX\nestx-frontend\src\constants

C:\Users\laure\NestX\nestx-frontend\src\pages
C:\Users\laure\NestX\nestx-frontend\src\pages\AuthPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ChatPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\DiscoverPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ForgotPasswordPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\LivePage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\LoginTestPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\NotificationsPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\PostDetailPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileCenterPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileConnectionsPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileLayoutPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileLeftPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileManagePage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfilePrivacySecurityPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileRightPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileSettingsPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ProfileVerificationPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\PromotedPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ResetPasswordPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\RulesPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\SearchPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\ShowcasePage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\TokensPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\UpdatesPage.tsx
C:\Users\laure\NestX\nestx-frontend\src\pages\VerifyEmailPage.tsx

C:\Users\laure\NestX\nestx-frontend\src\App.css
C:\Users\laure\NestX\nestx-frontend\src\App.tsx
C:\Users\laure\NestX\nestx-frontend\src\index.css
C:\Users\laure\NestX\nestx-frontend\src\main.tsx

C:\Users\laure\NestX\nestx-frontend\.env
C:\Users\laure\NestX\nestx-frontend\.gitignore
C:\Users\laure\NestX\nestx-frontend\eslint.config.js
C:\Users\laure\NestX\nestx-frontend\index.html
C:\Users\laure\NestX\nestx-frontend\package-lock.json
C:\Users\laure\NestX\nestx-frontend\package.json
C:\Users\laure\NestX\nestx-frontend\README.md
C:\Users\laure\NestX\nestx-frontend\tsconfig.app.json
C:\Users\laure\NestX\nestx-frontend\tsconfig.json
C:\Users\laure\NestX\nestx-frontend\tsconfig.node.json
C:\Users\laure\NestX\nestx-frontend\vite.config.ts

C:\Users\laure\NestX\rules
C:\Users\laure\NestX\rules\sezione rules sx EN
C:\Users\laure\NestX\rules\sezione rules sx EN\2_ACCOUNT TYPES & STATUS.html
C:\Users\laure\NestX\rules\sezione rules sx EN\3_TOKENS & ECONOMY (Overview).html
C:\Users\laure\NestX\rules\sezione rules sx EN\4_LIVE, EVENTS & CAM.html
C:\Users\laure\NestX\rules\sezione rules sx EN\5_ADV & PROMOTION SYSTEM.html
C:\Users\laure\NestX\rules\sezione rules sx EN\6_SHOWCASE.html
C:\Users\laure\NestX\rules\sezione rules sx EN\7_VERIFICATION & AUTHENTICITY.html
C:\Users\laure\NestX\rules\sezione rules sx EN\8_8️⃣ MODERATION & SAFETY.html
C:\Users\laure\NestX\rules\sezione rules sx EN\indice generale.html
C:\Users\laure\NestX\rules\sezione rules sx IT
C:\Users\laure\NestX\rules\sezione rules sx IT\3_TOKENS & ECONOMY (Overview).html